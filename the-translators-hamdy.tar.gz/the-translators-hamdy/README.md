# the-translators

#To run the front end
        $npm install
        $ng serve

#To run both front and back end
        $npm install
        $nodemon