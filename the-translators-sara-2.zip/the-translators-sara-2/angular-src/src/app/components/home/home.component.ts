import { Component, OnInit } from '@angular/core';

// import { GithubUser } from '../model/IGithubUser'; gym model
// import { GithubUser } from '../model/IGithubUser'; product model
//import { GithubUser } from '../model/IGithubUser'; service model

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
