export class Product {
  businessUserName: String;
  prodname: String;
  prodID: number;
  price: number;
  image: String;
  ProductDescription: String;
  Category: String;
  Quantity: number;
}