import {ProductService} from './product.service';

export const SERVICES =  [
    ProductService
]