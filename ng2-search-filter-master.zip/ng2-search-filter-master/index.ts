/**
 * Created by vadimdez on 28/11/2016.
 */
export * from './src/ng2-filter.module';
export * from './src/ng2-filter.pipe';